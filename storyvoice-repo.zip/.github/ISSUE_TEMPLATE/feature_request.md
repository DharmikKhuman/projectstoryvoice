---
name: Feature request
about: Suggest an idea for StoryVoice
title: "[Idea] "
labels: enhancement
---

**What problem would this solve?**
For example: "I can't tell which character is speaking when..."

**What would you like to happen?**

**Anything else?**
Examples from other apps, sketches or links.
