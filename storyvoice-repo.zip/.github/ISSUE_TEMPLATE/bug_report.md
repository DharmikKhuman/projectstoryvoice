---
name: Bug report
about: Something isn't working
title: "[Bug] "
labels: bug
---

**What happened?**
A clear description of the problem.

**Steps to reproduce**
1.
2.
3.

**What did you expect to happen?**

**Your setup**
- Browser and version (e.g. Edge 131):
- Device (e.g. Windows laptop, iPhone 15):
- File type (PDF, EPUB, TXT, ...):
- Voices (Kokoro or browser voices):

**Diagnostics**
Paste the grey "Sound:" line from **Character studio → Test sound**, if you can open it.

**Screenshots or console errors**
