## What does this change?

Closes #

## How did you test it?

- [ ] Uploading a PDF and an EPUB still works
- [ ] Playback, skip, speed and chapter navigation work
- [ ] Tested in Edge and Chrome
- [ ] Checked on a narrow (phone-sized) window
- [ ] No errors in the browser console

## Screenshots (for visual changes)
